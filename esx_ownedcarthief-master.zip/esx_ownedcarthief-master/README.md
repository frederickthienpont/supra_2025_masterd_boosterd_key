# esx_ownedcarthief

Allows stolen & sold vehicles owned by other players.
Player need to contact a mecano to install one of the 3 alarm system on ther car.
Only mecano can buy alarm system in the pawnshop and install it on a car.

Items
-Hammer & wire cutter
This tool can unlock a vehicle with a low rate of success but triggers alarm systems all the time.

-Burglary tools (Illegal)
This tool can unlock a vehicle with a normal pass rate and a low chance of triggering the alarm systems.

-Signal jammer (Illegal)
This tool allows a burglar to shut down advanced alarm systems once released into the vehicle

-Interface of alarm system
This tool allows a police officer to shut down advanced alarm systems.

-Basic alarm system
This system starts an audible alarm when an attempt is made to open a door without the key.

-Alarm system connect to the central
This system starts an audible alarm when an attempt is made to open a door without the key.
This system sends the vehicle's position to the police officer if an attempt is made to open a door without the key.

-High tech alarm system with GPS
This system starts an audible alarm when an attempt is made to open a door without the key.
This system sends the vehicle's position to the police officer if an attempt is made to open a door without the key.
This system sends the vehicle's position in REAL-TIME to the policeman in case of starting the engine without the key.


# Installation
1. Download the .Zip from this repository.
2. Extract it with your favorite program.
3. Copy the project to your ressource folder.
4. Don't forget to import the esx_ownedcarthiefEN.sql file to your database.
5. Add "start esx_ownedcarthief" in your `server.cfg`


# Required resource
- EssentialMode 5.0.3
- Async 2.0
- Esx
- esx_vehicleshop actual version

# Created by
- Code - Alex Garcio     https://github.com/RedAlex
- Code - Alain Proviste  https://github.com/EagleOnee
- Translation PT/BR - iKaoticx https://github.com/iKaoticx
- Code based on the resources of https://github.com/ESX-Org
___
# esx_ownedcarthief

Permet de volé et de vendre les véhicules posseder par d'autre joueurs.
Le joueur doit contacter un mécano pour installer l’un des 3 systèmes d’alarme sur la voiture.
Seul le mécano peut acheter un système d'alarme dans le prêteur sur gages et l'installer sur une voiture.

Items
-Marteau & coupe fil
Cette outil peut déverrouiller un véhicule avec un taux de réusite faible mais déclanche les systems d'alarm a tout coup.

-Outils de cambriolage (Illégal)
Cette outil peut déverrouiller un véhicule avec un taux de réusite normal et une faible chance de déclanché les systems d'alarm.

-Brouilleur de Signal (Illégal)
Cette outil permet a un cambrioleur de couper les systems d'alarm avancé une fois déclanché dans le véhicule

-Interface de système d'alarm
Cette outil permet a un policier de couper les systems d'alarm avancé.

-Système d'alarm de base
Ce system démarre une alarme sonore en cas de tentative d'ouverture d'une porte sans la clé.

-Système d'alarm relier a la central
Ce system démarre une alarme sonore en cas de tentative d'ouverture d'une porte sans la clé.
Ce system envoie la position du véhicule au policier en cas de tentative d'ouverture d'une porte sans la clé.

-Système d'alarm high tech avec GPS
Ce system démarre une alarme sonore en cas de tentative d'ouverture d'une porte sans la clé.
Ce system envoie la position du véhicule au policier en cas de tentative d'ouverture d'une porte sans la clé.
Ce system envoie la position du véhicule EN TEMPS RÉEL au policier en cas de de démarrage du moteur sans la clé.


# Installation
1. Téléchargez le .Zip
2. Extractez-le avec votre programme favori.
3. Copiez le projet dans votre dossier ressource.
4. N'oubliez pas d'importer le esx_ownedcarthiefFR.sql a votre base de données.
5. Ajoutez "start esx_ownedcarthief" dans votre `server.cfg`


# Ressource requis
- EssentialMode 5.0.3
- Async 2.0
- Esx
- esx_vehicleshop Version actuel


# Créer par
- Code - Alex Garcio    https://github.com/RedAlex
- Code - Alain Proviste https://github.com/EagleOnee
- Traduction PT/BR - iKaoticx https://github.com/iKaoticx
- Code basé sur les ressource de https://github.com/ESX-Org
___
# esx_ownedcarthief

Permite roubar veículo de propiedade de outros jogadores.
O jogador precisa entrar em contato com um mecânico para instalar um dos 3 sistemas de alarme no carro.
Somente o mecânico pode comprar sistema de alarme na casa de penhores e instalar em um carro.

Items
-Hammer & wirecutter
Esta ferramenta pode desbloquear um veículo com uma baixa taxa de sucesso, mas e sistemas de alarme o tempo todo.

-Ferramentas de arrombamento (ilegal)
Esta ferramenta pode desbloquear um veículo com uma taxa de sucesso mediana e uma baixa chance de acionar os sistemas de alarme.

- Bloqueador de sinal
Esta ferramenta permite que um ladrão desligue os sistemas de alarme avançados, uma vez ativados no veículo

-Interface do sistema de alarme
Essa ferramenta permite que um policial desligue os sistemas de alarme avançados.

-Sistema de alarme básico
Este sistema inicia um alarme sonoro quando é feita uma tentativa de abrir uma porta sem a chave.

-Sistema de alarme conectar-se à central
Este sistema inicia um alarme sonoro quando é feita uma tentativa de abrir uma porta sem a chave.
Este sistema envia a posição do veículo ao policial se for feita uma tentativa de abrir uma porta sem a chave.

-Sistema de alarme de alta tecnologia com GPS
Este sistema inicia um alarme sonoro quando é feita uma tentativa de abrir uma porta sem a chave.
Este sistema envia a posição do veículo ao policial se for feita uma tentativa de abrir uma porta sem a chave.
Este sistema envia a posição do veículo em TEMPO REAL para o policial em caso o motor ligue sem a chave.


# Instalação
1. Download o arquivo esx_ownedcarthief.zip neste github.
2. Extraia com o seu programa favorito.
3. Copie o a pasta esx_ownedcarthief para o seu diretorio de resources.
4. Importe o aquivo SQL esx_ownedcarthiefBR.sql para sua database.
5. Adicione start esx_ownedcarthief no seu server.cfg.

# Resources requeridos
- EssentialMode 5.0.3
- Async 2.0 
- Esx
- esx_vehicleshop Versão Atual

# Criado por
- Script - Alex Garcio     https://github.com/RedAlex
- Script - Alain Proviste  https://github.com/EagleOnee
- Trandução PT/BR - iKaoticx https://github.com/iKaoticx
- Código baseado nos recursos de https://github.com/ESX-Org